1_case_bovine_dd: Bovine cases against DD motifs
1_case_bovine_de: Bovine cases against DE motifs	1_case_human_dd: Human cases against DD motifs	1_case_human_de: Human cases against DE motifs
1_control_bovine_dd: Bovine controls against DD motifs
1_control_bovine_de: Bovine controls against DE motifs
1_control_human_dd: Human controls against DD motifs
1_control_human_de: Human controls against de motifs
human.jpeg: PCA image of human records
bovine.jpeg: PCA image of bovine records
pca_bovine_results: PCA results of bovine records
pca_human_results: PCA resutsl of huamn records

All the other csv files are the rogianl files without any calcualtions straight out of teh slimprob software
